//
//  StandardCheckoutKit.h
//  StandardCheckoutKit
//
//  Created by Vinicius on 09/06/17.
//  Copyright © 2017 Paymentz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StandardCheckoutKit.
FOUNDATION_EXPORT double StandardCheckoutKitVersionNumber;

//! Project version string for StandardCheckoutKit.
FOUNDATION_EXPORT const unsigned char StandardCheckoutKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StandardCheckoutKit/PublicHeader.h>


